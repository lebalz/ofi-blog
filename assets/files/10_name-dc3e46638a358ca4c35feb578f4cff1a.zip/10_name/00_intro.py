from smartphone_connector import *
from random import *

device = Connector("https://io.gbsl.website", "Hansli")


# letzte Zeile im Code
device.disconnect()
