from smartphone_connector import *
from random import *

device = Connector("https://io.gbsl.website", "Hansli")

# aktuellen Playground (=Zeichenfläche) löschen
device.clear_playground()

# Playground konfigurieren
device.configure_playground(
    width=100,
    height=140,
    origin_x=50,  # der Ursprung soll in der Mitte liegen
    origin_y=70,
    color='pink'  # weisser Hintergrund
)

# hier ihre Initialen schreiben

# letzte Zeile im Code
device.disconnect()
