from smartphone_connector import *
from math import sqrt

device = Connector('https://io.gbsl.website', 'FooBar')

SQRT3 = sqrt(3)
device.clear_playground()
device.configure_playground(
    width=90,
    height=90,
    color='white',
    origin_x=0,
    origin_y=0
)

for index_x in range(11):
    for index_y in range(11):
        x = index_x * 10
        if index_y % 2 == 1:
            x = x - 5
        y = index_y * 5 * SQRT3
        device.add_line(x1=x, y1=y, x2=x + 10, y2=y, color=random_color(), line_width=1)
        device.add_line(x1=x, y1=y, x2=x + 5, y2=SQRT3 * 5 + y, color=random_color(), line_width=1)
        device.add_line(x1=x + 5, y1=SQRT3 * 5 + y, x2=x + 10, y2=y, color=random_color(), line_width=1)
        device.sleep(0.01)
device.disconnect()
