from smartphone_connector import Connector

device = Connector("https://io.gbsl.website", "Hansli")

# aktuellen Playground (=Zeichenfläche) löschen
device.clear_playground()

# Playground konfigurieren
device.configure_playground(
    width=180,
    height=180,
    origin_x=10,  # der Ursprung wird auf 10, 10 gesetzt
    origin_y=10,
    color='bisque'
)


# letzte Zeile im Code
device.disconnect()
