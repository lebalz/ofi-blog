from smartphone_connector import Connector
device = Connector('https://io.gbsl.website', 'FooBar')


# letzte Zeile im Programm: Verbindung mit Gerät beenden
device.disconnect()
