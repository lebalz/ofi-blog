# Die Bibliothek laden - sie nimmt uns viel Arbeit ab
from smartphone_connector import Connector


#                      Hier die DeviceID ihres Smartphones eingeben
#                                                    ↓
connector = Connector('https://io.gbsl.website', 'DeviceID')

# die Anzeigefarbe auf dem Smartphone auf rot setzen
connector.set_color('red')

# 0.5 Sekunden warten
connector.sleep(0.5)

# die Anzeigefarbe auf dem Smartphone auf cyan setzen
connector.set_color('orange')
