benutzername = input("Gib einen neuen Benutzernamen ein")
while len(benutzername) < 5:
    print("Der Benutzername ist zu kurz, gib einen längeren ein!")
    benutzername = input("Neuer Benutzername")

print(f"Ausgewählter Benutzername: {benutzername}")
