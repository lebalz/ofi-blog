ferien_ort = 'Spanien'
ferien_ort = 'Balkonien'
print(f'in den Ferien gingen wir nach {ferien_ort}')
