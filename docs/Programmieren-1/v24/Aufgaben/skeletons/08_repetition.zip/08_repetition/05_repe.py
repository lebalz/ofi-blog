while True:
    anzahl = input('Wie viele Sterne soll ich zeichnen?')
    if anzahl == 'x':
        break
    anzahl = int(anzahl)
    print('* ' * anzahl)

print('Fertig')
