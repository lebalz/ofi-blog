ferien_ort = input("Wo warst du in den Ferien?")
print(f'Ich war in {ferien_ort}.')
