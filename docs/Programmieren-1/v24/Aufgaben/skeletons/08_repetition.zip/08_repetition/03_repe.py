kmh = input("Wie schnell kannst du radfahren?")
ms = kmh / 3.6
print(f'Ich kann {kmh}km/h oder {ms}m/s schnell radfahren.')
