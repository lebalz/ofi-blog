while True:
    anzahl = input("Wie gross soll das Dreieck werden?")
    if anzahl == 'x':
        break
    for i in range(1, 6):
        print('* ' * i)
