from gtts import gTTS
from playsound import playsound

text = 'Hallo ich bin Elsa'

gruefnisch = text

print(gruefnisch)
