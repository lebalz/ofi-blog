from smartphone_connector import *
from gbsl_turtle import *

phone = Connector("https://io.gbsl.website", "Hansli")

Screen().tracer(1, 0)  # mache die Turtles maximal schnell

tim = Turtle()
jon = Turtle()

tim.pencolor('red')
jon.pencolor('blue')


def on_update(data: DataFrame):
    print(data.acceleration)


# phone.set_update_interval(0.1)
phone.subscribe(on_update, interval=0.01)
