from smartphone_connector import *
from gbsl_turtle import *

phone = Connector("https://io.gbsl.website", "Hansli")

Screen().tracer(1, 0)  # mache die Turtles maximal schnell
home()


def on_update(data: DataFrame):
    print(data.acceleration)


phone.subscribe(on_update, interval=0.01)
