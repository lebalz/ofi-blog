from smartphone_connector import *
from gbsl_turtle import *
from math import sqrt

phone = Connector("https://io.gbsl.website", "Hansli")


def on_f1():
    print("Hello F1")


phone.on_f1 = on_f1
Screen().mainloop()
