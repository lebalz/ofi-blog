from smartphone_connector import *
from gbsl_turtle import *

phone = Connector("https://io.gbsl.website", "Hansli")

home()


def on_key(data: KeyMsg):
    print(data)


phone.on_key = on_key

Screen().mainloop()
