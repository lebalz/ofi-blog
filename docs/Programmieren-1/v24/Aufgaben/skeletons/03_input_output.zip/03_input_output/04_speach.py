from gtts import gTTS  # Google Text To Speach Bibliothek
from playsound import playsound  # playsound Bibliothek um mp3 abzuspielen
