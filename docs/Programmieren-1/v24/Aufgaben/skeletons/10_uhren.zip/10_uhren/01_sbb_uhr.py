from smartphone_connector import Connector

device = Connector("https://io.gbsl.website", "Hansli")

# aktuellen Playground (=Zeichenfläche) löschen
device.clear_playground()

# Playground konfigurieren
device.configure_playground(
    width=100,
    height=100,
    origin_x=50,  # der Ursprung soll in der Mitte liegen
    origin_y=50,
    color='white'  # weisser Hintergrund
)


# letzte Zeile im Code
device.disconnect()
