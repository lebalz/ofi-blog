# Eine eigenständige Markdown-Seite

Hier können ausserhalb des Ordners `docs` oder `blog` Seiten hinzugefügt werden.